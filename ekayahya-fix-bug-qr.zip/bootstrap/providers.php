<?php

return [
    App\Providers\AppServiceProvider::class,
    Barryvdh\DomPDF\ServiceProvider::class,   // Service provider untuk PDF
    Maatwebsite\Excel\ExcelServiceProvider::class,  // Service provider untuk Excel
];
