<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Login - Digital Wedding</title>
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.svg')); ?>" type="image/svg+xml">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-100 font-sans antialiased">
    <div id="app">
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        
    </div>
</body>
</html>
<?php /**PATH C:\Users\ekaya\Downloads\SAMUEL WEDDING FIX FINAL ANJAY\ekayahya-fix-bug-qr\ekayahya-fix-bug-qr\resources\views/layouts/guest.blade.php ENDPATH**/ ?>