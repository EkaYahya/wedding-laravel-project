<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Digital Wedding</title>
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.svg')); ?>" type="image/svg+xml">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">


    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <!-- Font Awesome -->
    <script src="https://kit.fontawesome.com/811cf44b8d.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/webcam-easy@1.0.5/dist/webcam-easy.min.js"></script>
    <style>
        /* Layout Optimization for Mobile */
        body {
            max-width: 768px;
            margin: 0 auto;
            overflow-x: hidden;
        }
    </style>
</head>
<body class="bg-gray-100 font-sans antialiased">
    <div id="app">
        <!-- Main Content -->
        <main> <!-- Extra space for navbar -->
            <?php echo $__env->make('components.navbarTop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <!-- Include Navbar -->
        <?php if (! (Route::currentRouteName() === 'login')): ?>
            <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

    </div>
</body>
</html>


<?php /**PATH C:\Users\ekaya\Downloads\SAMUEL WEDDING FIX FINAL ANJAY\ekayahya-fix-bug-qr\ekayahya-fix-bug-qr\resources\views/layouts/app.blade.php ENDPATH**/ ?>