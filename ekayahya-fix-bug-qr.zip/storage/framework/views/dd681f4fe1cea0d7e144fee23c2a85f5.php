<?php $__env->startSection('title', 'Daftar Tamu'); ?>
<!-- route kehadiran-->
<?php $__env->startSection('content'); ?>
<div class="bg-primary-light min-h-screen py-8 pb-20">
    <!-- Statistik -->
    <div class="grid grid-cols-3 gap-6 mx-8 mb-6 mt-14">
        <?php $__currentLoopData = [
            ['title' => 'Undangan', 'value' => $totalGuests],
            ['title' => 'Hadir', 'value' => $totalAttended],
            ['title' => 'Tdk Hadir', 'value' => $totalGuests - $totalAttended],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="p-4 bg-primary-dark text-white rounded-lg shadow hover:shadow-lg transition-shadow duration-300">
            <p class="text-2xl font-bold text-center"><?php echo e($stat['value']); ?></p>    
            <h4 class="text-sm font-semibold text-center"><?php echo e($stat['title']); ?></h4>   
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="container mx-auto px-6 pb-20">
        <div class="flex justify-between items-center mb-8">
            <h1 class="text-3xl font-bold text-primary-dark">Kehadiran</h1>
        </div>
        <!-- Tombol Ekspor PDF dan Excel -->
        <div class="flex justify-start items-center mb-4">
            <a href="<?php echo e(route('guests.exportPDF')); ?>" class="px-4 py-2 bg-primary-dark text-white rounded shadow hover:bg-primary focus:ring-2 focus:ring-primary-light mr-2">
                Export PDF
            </a>
            <a href="<?php echo e(route('guests.exportExcel')); ?>" class="px-4 py-2 bg-primary-dark text-white rounded shadow hover:bg-primary focus:ring-2 focus:ring-primary-light">
                Export Excel
            </a>
        </div>

        <!-- Tabel Tamu -->
        <div class="bg-white shadow rounded-lg overflow-hidden">
            <div class="p-4 bg-primary-dark">
            <form id="search-form" class="flex items-center gap-2" method="GET" action="<?php echo e(route('guests.index')); ?>">
                <input type="text" id="search-input" name="search" placeholder="Cari tamu..." class="px-4 py-2 border rounded-lg w-full focus:ring-2 focus:ring-primary outline-none" aria-label="Cari tamu" value="<?php echo e(request('search')); ?>">
                <button type="submit" class="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition focus:ring-2 focus:ring-primary-light" aria-label="Cari">Cari</button>
            </form>
            </div>
            <table class="min-w-full bg-white relative">
            <thead class="bg-primary-dark text-primary-light">
                <tr>
                        <th class="py-3 px-4 border-b text-start">Nama</th>
                        <th class="py-3 px-2 border-b">
                        <a href="<?php echo e(route('guests.create')); ?>" class="px-2 py-2 bg-primary-white text-bg-primary rounded shadow hover:bg-primary focus:ring-2 focus:ring-primary-light">
                            <i class="fa-solid fa-user-plus"></i>
                        </a>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $guests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-primary-light/50 transition-colors duration-200">
                        <td class="py-3 px-4 border-b text-primary-dark"><?php echo e($guest->name); ?><br>
                        <span class="text-xs text-gray-500">
                            <?php echo e($guest->phone_number); ?> | <?php echo e($guest->guest_type); ?> | 
                            <?php if($guest->will_attend): ?>
                                <span class="bg-white-100 text-white-500">akan hadir |</span>
                            <?php else: ?>
                                <span class="bg-white-100 text-white-500">tdk akan hadir |</span>
                            <?php endif; ?>
                            <?php if($guest->attended): ?>
                                <span class="bg-green-100 text-green-500">hadir</span>
                            <?php else: ?>
                                <span class="bg-red-100 text-red-500">tdk hadir</span>
                            <?php endif; ?>
                        </span>
                        </td>
                        <td class="py-3 px-4 border-b text-center relative">
                            <div class="relative inline-block text-xs text-gray-500"><?php echo e($guest->updated_at); ?></div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="m-4">
                <?php echo e($guests->links()); ?>

            </div>
            <!-- Dropdown Container -->
            <div id="dropdown-container" class="hidden absolute right-0 bg-white border rounded-lg shadow-md mt-2 text-sm z-50 w-48">
                <ul id="dropdown-actions">
                    <!-- Actions will be dynamically inserted here -->
                </ul>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ekaya\Downloads\SAMUEL WEDDING FIX FINAL ANJAY\ekayahya-fix-bug-qr\ekayahya-fix-bug-qr\resources\views/guests/index.blade.php ENDPATH**/ ?>