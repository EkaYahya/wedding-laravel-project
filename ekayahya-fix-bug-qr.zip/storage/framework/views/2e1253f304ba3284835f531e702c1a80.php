<?php $__env->startSection('title', 'Check-In Tamu'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-primary-light min-h-screen py-8 ">
    <!-- Header dan Statistik -->
    <div class="flex items-center justify-between px-8 py-4 mt-20 mx-20  bg-primary-dark text-white rounded-lg shadow mb-6">
        <div class="text-center">
        <h2 class="text-4xl font-bold"><?php echo e($totalCheckedIn); ?></h2>
        <p>Tamu Sudah Check-In</p>
        </div>
    </div>

    <!-- Daftar Check-In -->
    <div class="container mx-auto px-6 pb-20">
        <h2 class="text-xl font-bold text-primary-dark mb-4">Daftar Check-In</h2>
        <div class="bg-white shadow rounded-lg p-4">
             <?php if($guests->isEmpty()): ?>
                <p class="text-center text-gray-500">Tidak ada tamu yang sudah check-in.</p>
            <?php else: ?>
                <?php $__currentLoopData = $guests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center justify-between border-b pb-4 mb-4">
                        <div>
                            <h3 class="text-lg font-bold text-primary-dark"><?php echo e($guest->name); ?></h3>
                        </div>
                        <span class="text-xs text-gray-500"> 
                            <?php if($guest->attended): ?>
                                <span class="bg-green-100 text-green-500">Sudah Ambil Voucher</span>
                            <?php else: ?>
                                <span class="bg-red-100 text-red-500">Belum Ambil Voucher</span>
                            <?php endif; ?>
                        </span>
                        
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- Pagination Links -->
                <div class="mt-4 flex justify-center">
                    <div class="pagination flex items-center space-x-2">
                        <!-- Previous Page Link -->
                        <?php if($guests->onFirstPage()): ?>
                            <span class="px-3 py-1 bg-gray-300 text-gray-500 cursor-not-allowed rounded-md">Prev</span>
                        <?php else: ?>
                            <a href="<?php echo e($guests->previousPageUrl()); ?>" class="px-3 py-1 bg-primary text-white rounded-md hover:bg-primary-dark">Prev</a>
                        <?php endif; ?>

                        <!-- Pagination Numbers -->
                        <?php $__currentLoopData = $guests->getUrlRange(1, $guests->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $guests->currentPage()): ?>
                                <span class="px-3 py-1 bg-primary text-white rounded-md"><?php echo e($page); ?></span>
                            <?php else: ?>
                                <a href="<?php echo e($url); ?>" class="px-3 py-1 bg-gray-200 text-primary-dark rounded-md hover:bg-primary-light"><?php echo e($page); ?></a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- Next Page Link -->
                        <?php if($guests->hasMorePages()): ?>
                            <a href="<?php echo e($guests->nextPageUrl()); ?>" class="px-3 py-1 bg-primary text-white rounded-md hover:bg-primary-dark">Next</a>
                        <?php else: ?>
                            <span class="px-3 py-1 bg-gray-300 text-gray-500 cursor-not-allowed rounded-md">Next</span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ekaya\Downloads\SAMUEL WEDDING FIX FINAL ANJAY\ekayahya-fix-bug-qr\ekayahya-fix-bug-qr\resources\views/guests/checkin.blade.php ENDPATH**/ ?>