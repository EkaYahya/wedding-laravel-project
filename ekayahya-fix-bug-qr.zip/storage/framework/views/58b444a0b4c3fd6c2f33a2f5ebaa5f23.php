<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-center min-h-screen bg-primary-dark">
    <div class="w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-lg">
        <!-- <h2 class="text-3xl font-bold text-center text-primary-dark"><?php echo e(__('Login')); ?></h2> -->

        <form method="POST" action="<?php echo e(route('login')); ?>" class="space-y-6">
            <?php echo csrf_field(); ?>

            <!-- Input Email -->
            <div>
                <label for="email" class="block text-sm font-medium text-primary-dark"><?php echo e(__('Email Address')); ?></label>
                <input id="email" type="email" class="block w-full px-4 py-2 mt-2 text-primary-dark bg-gray-100 border border-gray-300 rounded focus:ring focus:ring-primary-light focus:border-primary-dark <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-sm text-danger mt-1" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Input Password -->
            <div>
                <label for="password" class="block text-sm font-medium text-primary-dark"><?php echo e(__('Password')); ?></label>
                <input id="password" type="password" class="block w-full px-4 py-2 mt-2 text-primary-dark bg-gray-100 border border-gray-300 rounded focus:ring focus:ring-primary-light focus:border-primary-dark <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-sm text-danger mt-1" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Checkbox Remember Me -->
            <div class="flex items-center">
                <input type="checkbox" name="remember" id="remember" class="w-4 h-4 text-primary-dark border-gray-300 rounded focus:ring-primary-light" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                <label for="remember" class="ml-2 text-sm text-primary-dark"><?php echo e(__('Remember Me')); ?></label>
            </div>

            <!-- Login Button -->
            <div>
                <button type="submit" class="w-full px-4 py-2 font-semibold text-white bg-primary-dark rounded-md hover:bg-primary focus:ring-2 focus:ring-primary-light">
                    <?php echo e(__('Login')); ?>

                </button>
            </div>

            <!-- Footer -->
            <div class="text-center text-sm text-gray-500 mt-4">
                Copyright © 2024 Digitalinkuy. All Rights Reserved.<br>
                Made by <a href="https://www.digitalinkuy.com/" class="font-bold text-primary hover:underline">Digitalinkuy</a>.
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ekaya\Downloads\SAMUEL WEDDING FIX FINAL ANJAY\ekayahya-fix-bug-qr\ekayahya-fix-bug-qr\resources\views/auth/login.blade.php ENDPATH**/ ?>